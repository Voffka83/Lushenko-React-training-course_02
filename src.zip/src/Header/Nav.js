import React from 'react';


function Nav(props) {
	return (
		<div>
			<nav>
				<ul class="main-navigation">
					
					здесь будет распечатан props
				</ul>
			</nav>
		</div>
	);
}


export default Nav;
