import Nav from './Header/Nav';
import React from 'react';



function Header(props) {
	return (
		
		<header>
			<h1>site_name</h1>
			<h2>site_title</h2>
			<Nav />
				
		</header>
		
	);
}





export default Header;