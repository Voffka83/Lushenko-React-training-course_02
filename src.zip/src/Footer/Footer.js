import React from 'react';
import Nav from '../Header/Nav';

function Footer(props) {
	return (
		<div>
			<footer>
			<h3>site_name</h3>
			<Nav />
					
			</footer>
		</div>
	);
}


export default Footer;