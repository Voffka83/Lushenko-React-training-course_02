import Test2 from './Test2';

function Test() {
    return (
        <>
            <h1>Test component 1</h1>
            <Test2 />
        </>
    );
}

export default Test;