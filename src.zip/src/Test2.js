import React from 'react';

class Test2 extends React.Component {
    render() {
        return (
            <h2>Test 2 Component</h2>
        );
    }
}


export default Test2;