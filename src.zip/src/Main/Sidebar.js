import Nav from '..Header/Nav';
import React from 'react';


function Sidebar() {
	return (
		<div>
			<ul>
			<li>Страница 1</li>
			<li>Страница 2</li>
			<li>Страница 3</li>
			</ul>
		</div>
	);
}

export default Sidebar;
