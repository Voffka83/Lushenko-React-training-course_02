import React from 'react';


function Main() {
	return (
		<div>
			<p>Text example</p>
		</div>
	);
}

export default Main;
